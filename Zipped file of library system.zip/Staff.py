from utility import details_of_customer_with_books

def staff():
        secret_code=int(input("Enter the Staff Code: "))
        if secret_code== 2315:  
            print("Access Granted")  
            print(details_of_customer_with_books)
        else:
              print("Access Denied")
              print("Please,Enter Valid Staff Code")