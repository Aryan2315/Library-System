from Book_List import book_list

def add_book():
    Add= input("\nEnter The Book Name Which You Want to Donate:\n")
    book_list.append(Add)
    if Add in book_list:
        print('\nYOU HAVE SUCCESFULLY DONATED TO THE BOOK\n')
    else:
        print('\nTRY AGAIN\n')