from utility import issued_book
from Book_List import book_list
from utility import details_of_customer_with_books


def book_return():
    Return= input("Enter the book name which is you want to return:")
    if Return in issued_book:
        issued_book.remove(Return)
        book_list.append(Return)
        print("Thanks for reading the book and choosin goue library")
    else: 
        print("This book is not issued till now")
def staff():
    print(details_of_customer_with_books)
def options():
    print("Please Select Your Choice")
    print("Press 1 to check available books in library\n" \
    "Press 2 to donate any book\n" \
    "Press 3 to Book issue\n" \
    "Press 4 to return the issued book\n Press 5 if you are the staff of library and want to check the data of library")
