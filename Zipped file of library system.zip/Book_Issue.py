from Book_List import book_list
from datetime import datetime
from utility import details_of_customer_with_books,issued_book

def book_issue():
    print("\nAvailable Books in Library:\n")
    for b in book_list:
        print(b)
    Name=input("\nEnter Your Name\n")
    Contact_Detail=input("\nEnter Your Contact Number:\n")
    period=input("\nHow many days Do you want to keep th book:\n")
    Date_Detail=str(datetime.now())
    Issue=input("\nEnter the book name which book you want to issue:\n")

    if Issue in book_list:      
        issued_book.append(Issue)
        book_list.remove(Issue)
        details_of_customer_with_books[Contact_Detail]={"Name":Name,
                                                        "Time_Period":period,
                                                        "Issued_Book":Issue,
                                                        "Date":Date_Detail}
        print("Thanks to choose me for Reading")
    else:
        print(Issue,", Currently this book is not in the Library")