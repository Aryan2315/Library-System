
def options():
    print("Please Select Your Choice")
    print("Press 1 to check available books in library\n" \
    "Press 2 to donate any book\n" \
    "Press 3 to Book issue\n" \
    "Press 4 to return the issued book\n Press 5 if you are the staff of library and want to check the data of library")
