from Add_Book import add_book

from Book_Issue import book_issue

from Book_Returned import book_return

from Book_List import book_list

from display_books import display_books

from utility import issued_book, details_of_customer_with_books

from choices import options

from Staff import staff


while True:
    print("\n")
    options()
    customer_choice=int(input("\nEnter Your Choice from above choices: "))
    if customer_choice>=1 and customer_choice<=5:
        if customer_choice==1:
            print("These Books are available in the library")
            display_books()
        elif customer_choice==2:
            add_book()
        elif customer_choice==3:
            book_issue()
        elif customer_choice==4:
            book_return()
        elif customer_choice==5:
            staff()
            
    else:
        print("\nSelect the options carefully\n")
        pass
    print("\n\n\n\n\n")